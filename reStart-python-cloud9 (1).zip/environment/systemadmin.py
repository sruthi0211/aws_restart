import subprocess
command="df"
print('Gathering system information with command: '.format(command))
subprocess.run([command])