myString="this is a string"
print(myString)