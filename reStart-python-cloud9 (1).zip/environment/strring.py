name = input("what is your name?")
color = input("what is your fav color?")
animal = input("what is your fav animal?")
print("{}, you lika a {} {}!".format(name, color,animal))