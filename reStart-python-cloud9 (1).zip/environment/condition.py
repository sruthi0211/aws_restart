userReply = input("Do you need to ship a package? (Enter stamps, envelop or copy)")
if userReply == "stamps":
    print("We have many stamp designs to choose from.!")
elif userReply == "envelop":
    print("We have many envelope sizes to choose from.")
elif userReply == "copy":
    copies = input("How many copies would you like? (Enter a number) ")
    print("Here are {} copies.".format(copies))
else:
    print("Thank you, please come again.")