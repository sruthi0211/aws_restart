mylist = [45,454545, 1.02, True, "my dog is on the bed", "45"]
print(mylist)
for item in mylist:
    print("{} is of the data type {}".format(item, type(item)))